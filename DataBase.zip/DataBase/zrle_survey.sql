-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: zrle
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `survey`
--

DROP TABLE IF EXISTS `survey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `survey` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` text,
  `Q1` text,
  `Q2` text,
  `Q3` text,
  `Q4` text,
  `Q5` text,
  `Q6` text,
  `A1` double DEFAULT NULL,
  `A2` double DEFAULT NULL,
  `A3` double DEFAULT NULL,
  `A4` double DEFAULT NULL,
  `A5` double DEFAULT NULL,
  `A6` double DEFAULT NULL,
  `Conclusion` text,
  `Status` text,
  `Num_Of_Participant` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=30007 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `survey`
--

LOCK TABLES `survey` WRITE;
/*!40000 ALTER TABLE `survey` DISABLE KEYS */;
INSERT INTO `survey` VALUES (30000,'01/01/2017','Rank the service customer to your opinion','Do you think you will order again in the future?','Will you recommand to your friends to buy in ZerLi?','Do you like your last orders?','Rank the service of our delivery','In generally, do you feel satisfied from ZerLi?',3.3,7.7,6.7,5.5,9.9,3.7,'The stores are fine','No Active',4),(30001,'01/05/2017','Rank the service customer to your opinion','Do you think you will order again in the future?','Will you recommand to your friends to buy in ZerLi?','Do you like your last orders?','Rank the service of our delivery','In generally, do you feel satisfied from ZerLi?',5.6,4.7,2.3,8.9,10,4.7,'The stores improvement her service','No Active',4),(30002,'01/08/2017','Rank the service customer to your opinion','Do you think you will order again in the future?','Will you recommand to your friends to buy in ZerLi?','Do you like your last orders?','Rank the service of our delivery','In generally, do you feel satisfied from ZerLi?',6.6,7.7,4.1,8.8,9.9,6.7,'ZerLi employees do the besta','No Active',4),(30003,'01/11/2017','Rank the service customer to your opinion','Do you think you will order again in the future?','Will you recommand to your friends to buy in ZerLi?','Do you like your last orders?','Rank the service of our delivery','In generally, do you feel satisfied from ZerLi?',1.7,4.5,4.8,5.5,6.1,2.3,'There is decreasing in service customer','No Active',4),(30004,'21/01/2018','Rank the service customer to your opinion','Do you think you will order again in the future?','Will you recommand to your friends to buy in ZerLi?','Do you like your last orders?','Rank the service of our delivery','In generally, do you feel satisfied from ZerLi?',0.65,0.65,0.65,0.65,0.65,0.65,'fdfg','No Active',8),(30005,'27/01/2018','sdf','sdf','sdf','sdf','sdf','sdf',NULL,NULL,NULL,NULL,NULL,NULL,'asdas','No Active',0),(30006,'27/01/2018','sdf','sdf','sdf','sdf','sdf','sdfff',NULL,NULL,NULL,NULL,NULL,NULL,'asdas','No Active',0);
/*!40000 ALTER TABLE `survey` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-31  3:00:26
