-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: zrle
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `complaine`
--

DROP TABLE IF EXISTS `complaine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaine` (
  `ComplaineID` int(11) NOT NULL AUTO_INCREMENT,
  `BranchID` varchar(45) NOT NULL,
  `ComplaineText` varchar(255) NOT NULL,
  `UserID` varchar(45) NOT NULL,
  `Date` varchar(45) NOT NULL,
  `Time` varchar(45) NOT NULL,
  `ComplaineTopic` varchar(45) NOT NULL,
  `ComplaineStatus` varchar(45) NOT NULL,
  `ComplaineAnswer` varchar(45) DEFAULT NULL,
  `RefoundID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ComplaineID`,`BranchID`),
  KEY `FKuser_idx` (`UserID`),
  KEY `FKrefound_idx` (`RefoundID`),
  CONSTRAINT `FKrefound` FOREIGN KEY (`RefoundID`) REFERENCES `refound` (`RefoundID`),
  CONSTRAINT `FKuser` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaine`
--

LOCK TABLES `complaine` WRITE;
/*!40000 ALTER TABLE `complaine` DISABLE KEYS */;
INSERT INTO `complaine` VALUES (1,'1','The flowers was broken','Sentia','12/12/2017','18:06','Bad Quality of Product','1',' We Are Sorry ',2),(2,'2','This Isnot What i Ordered','Rabab','24/01/2018','14:36','Wrong Delivry','1','asdas',NULL),(3,'3','The product Quailty was too bad','Rami','17/01/2018','17:22','Bad Quality of Product','0',NULL,NULL);
/*!40000 ALTER TABLE `complaine` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-31  3:00:25
