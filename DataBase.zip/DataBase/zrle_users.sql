-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: zrle
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `UserID` varchar(45) NOT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `FirstName` varchar(45) DEFAULT NULL,
  `LastName` varchar(45) DEFAULT NULL,
  `Email` varchar(45) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `LoginStatus` int(1) DEFAULT NULL,
  `UserType` int(1) DEFAULT NULL,
  `UserStatus` int(1) DEFAULT NULL,
  `AddressID` int(11) NOT NULL,
  `BranchID` varchar(45) DEFAULT NULL,
  `numoftries` int(1) DEFAULT NULL,
  `lastLogin` timestamp(6) NULL DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  KEY `FKusers941891` (`AddressID`),
  CONSTRAINT `FKusers941891` FOREIGN KEY (`AddressID`) REFERENCES `address` (`AddressID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('Amany','134','Amany','Attallah','Amany@gmail.com','0503092017',0,2,1,12,'5',3,NULL),('Ameer','124','Amer','nset','amer@gmail.com','0503092008',0,2,0,2,'0',0,NULL),('Amir','131','Amir','Amara','Amir@gmail.com','0503092002',0,5,0,9,'2',0,NULL),('Bshara','140','Bshara','Khames','Bshara@gmail.com','0503092011',0,7,0,18,'1',0,NULL),('Elanet','136','Elanet','Slador','Elanet@gmail.com','0503092015',0,7,0,14,'1',0,NULL),('Firas','125','Firas','Ghadban','Firas@gmail.com','0503092007',0,3,1,3,'1',4,NULL),('Jawad','129','Jawad','Rizek','Jawad@gmail.com','0503092001',0,3,0,7,'5',0,NULL),('Jeries','123','Jeries','Zamel','zamel.65@gmail.com','0503092009',0,0,0,1,'1',0,NULL),('Jhony','126','Jhony','Salom','Jhony@gmail.com','0503092006',0,4,0,4,'2',0,NULL),('Maria','137','Maria','Deeb','maria@gmai.com','0503092014',0,8,0,15,'1',0,NULL),('Marshod','133','Marshod','Ayob','Marshod@gmail.com','0503092018',0,5,0,11,'4',0,NULL),('Nidal','130','Nidal','Nawatha','Nidal@gmail.com','050309202',0,5,0,8,'1',0,NULL),('Rabab ','139','Rabab ','Khalel','Rabab@gmail.com','0503092012',0,7,0,17,'1',0,NULL),('Rami','141','Rami','Salem','Rami@gmail.com','0503092010',0,2,0,19,'4',0,NULL),('Salem','142','Salem','Sool','Saleem@gmail.com','0503092003',0,2,1,20,'0',0,NULL),('Sentia','138','Sentia','Faraj','Sentia@gmail.com','0503092013',0,2,0,16,'1',0,NULL),('Sojoid','135','Sojoud','Hourane','Sojoud@gmail.com','0503092016',0,6,0,13,'1',0,NULL),('Waled','128','Waled','Rizek','Waled@gmail.com','0503092004',0,4,0,6,'4',0,NULL),('Wisam','127',' Wisam','Smara','Wisam@gmail.com','0503092005',0,4,0,5,'3',0,NULL),('Ziad ','132','Ziad ','Nasrawei','Ziad@gmail.com','0503092019',0,5,0,10,'3',0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-31  3:00:24
