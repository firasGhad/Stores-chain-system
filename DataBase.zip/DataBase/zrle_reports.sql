-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: zrle
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `ReportID` varchar(45) NOT NULL,
  `ReportDate` varchar(45) DEFAULT NULL,
  `ReportFile` blob,
  `ReportType` varchar(45) DEFAULT NULL,
  `BranchID` varchar(45) DEFAULT NULL,
  `ReportQuart` varchar(45) DEFAULT NULL,
  `Year` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT '0',
  `ManagerID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ReportID`),
  KEY `FKreports456217` (`BranchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES ('110','2017-03-01 00:00:00','15/1 20 30/1 10 15/2 20 30/2 10 15/3 20 30/3 10','IncomeReport','1','1','2017','0',NULL),('111','2017-03-01 00:00:00','ArrangmentFlowers 66  FloweringPlant 93 BridalBouquet 90 ClusterOfFlowers 10\r\n			    ','OrdersReport','1','1','2017','0',NULL),('119','2017-03-01 00:00:00','15/4 34 30/4 10 15/5 34 30/5 74  15/6 34 30/6 13','IncomeReport','1','2','2017','0',NULL),('120','2017-03-01 00:00:00','15/7 4 30/7 40 15/8 88 30/8 78  15/9 64 30/9 45','IncomeReport','1','3','2017','0',NULL),('13','2017-03-01 00:00:00','15/10 55 30/10 67 15/11 99 30/11 70  15/12 34 30/12 45','IncomeReport','1','4','2017','0',NULL),('14','2017-03-01 00:00:00','15/1 34 30/1 40 15/2 34 30/2 7 15/3 34 30/3 4','IncomeReport','2','1','2017','0',NULL),('15','2017-03-01 00:00:00','15/4 34 30/4 40 15/5 34 30/5 70  15/6 34 30/6 45','IncomeReport','2','2','2017','0',NULL),('16','2017-03-01 00:00:00','15/7 34 30/7 40 15/8 34 30/8 70  15/9 34 30/9 45','IncomeReport','2','3','2017','0',NULL),('17','2017-03-01 00:00:00','15/1 34 30/1 40 15/2 34 30/2 70  15/3 34 30/3 45','CustomerSatisfactionReport','1','1','2017','0',NULL),('18','2017-03-01 00:00:00','15/4 34 30/4 10 15/5 34 30/5 74  15/6 34 30/6 13','CustomerSatisfactionReport','1','2','2017','0',NULL),('19','2017-03-01 00:00:00','15/7 4 30/7 40 15/8 88 30/8 78  15/9 64 30/9 45','CustomerSatisfactionReport','1','3','2017','0',NULL),('20','2017-03-01 00:00:00','15/10 55 30/10 67 15/11 99 30/11 70  15/12 34 30/12 45','CustomerSatisfactionReport','1','4','2017','0',NULL),('21','2017-03-01 00:00:00','15/1 34 30/1 40 15/2 34 30/2 7 15/3 34 30/3 4','CustomerSatisfactionReport','2','1','2017','0',NULL),('22','2017-03-01 00:00:00','15/4 34 30/4 40 15/5 34 30/5 70  15/6 34 30/6 45','CustomerSatisfactionReport','2','2','2017','0',NULL),('222','2017-03-01 00:00:00','ArrangmentFlowers 45  FloweringPlant 43 BridalBouquet 90 ClusterOfFlowers 10\r\n			    ','OrdersReport','1','2','2017','0',NULL),('23','2017-03-01 00:00:00','15/7 34 30/7 40 15/8 34 30/8 70  15/9 34 30/9 45','CustomerSatisfactionReport','2','3','2017','0',NULL),('24','2017-03-01 00:00:00','15/10 34 30/10 40 15/11 34 30/11 70  15/12 34 30/12 45','CustomerSatisfactionReport','2','4','2017','0',NULL),('25','0000-00-00 00:00:00','15/1 34 30/1 40 15/2 34 30/2 70  15/3 34 30/3 45','ComplaintsReport','1','1','2017','0',NULL),('26','0000-00-00 00:00:00','15/4 34 30/4 10 15/5 34 30/5 74  15/6 34 30/6 13','ComplaintsReport','1','2','2017','0',NULL),('27','0000-00-00 00:00:00','15/7 4 30/7 40 15/8 88 30/8 78  15/9 64 30/9 45','ComplaintsReport','1','3','2017','0',NULL),('28','0000-00-00 00:00:00','15/10 55 30/10 67 15/11 99 30/11 70  15/12 34 30/12 45','ComplaintsReport','1','4','2017','0',NULL),('29','0000-00-00 00:00:00','15/1 34 30/1 40 15/2 34 30/2 7 15/3 34 30/3 4','ComplaintsReport','2','1','2017','0',NULL),('30','0000-00-00 00:00:00','15/4 34 30/4 40 15/5 34 30/5 70  15/6 34 30/6 45','ComplaintsReport','2','2','2017','0',NULL),('31','0000-00-00 00:00:00','15/7 34 30/7 40 15/8 34 30/8 70  15/9 34 30/9 45','ComplaintsReport','2','3','2017','0',NULL),('32','0000-00-00 00:00:00','15/10 34 30/10 40 15/11 34 30/11 70  15/12 34 30/12 45','ComplaintsReport','2','4','2017','0',NULL),('333','2017-03-01 00:00:00','ArrangmentFlowers 45  FloweringPlant 43 BridalBouquet 30 ClusterOfFlowers 10\r\n			    ','OrdersReport','1','3','2017','0',NULL),('444','2017-03-01 00:00:00','ArrangmentFlowers 45  FloweringPlant 43 BridalBouquet 90 ClusterOfFlowers 10\r\n			    ','OrdersReport','1','4','2017','0',NULL),('555','2017-03-01 00:00:00','ArrangmentFlowers 45  FloweringPlant 43 BridalBouquet 90 ClusterOfFlowers 50\r\n			    ','OrdersReport','2','1','2017','0',NULL),('666','2017-03-01 00:00:00','ArrangmentFlowers 35  FloweringPlant 43 BridalBouquet 70 ClusterOfFlowers 10\r\n			    ','OrdersReport','2','2','2017','0',NULL),('777','2017-03-01 00:00:00','ArrangmentFlowers 45  FloweringPlant 53 BridalBouquet 55 ClusterOfFlowers 10\r\n			    ','OrdersReport','2','3','2017','0',NULL),('888','2017-03-01 00:00:00','ArrangmentFlowers 66  FloweringPlant 93 BridalBouquet 90 ClusterOfFlowers 10\r\n			    ','OrdersReport','2','4','2017','0',NULL),('999','2017-03-01 00:00:00','15/10 34 30/10 40 15/11 34 30/11 70  15/12 34 30/12 45','IncomeReport','2','4','2017','0',NULL);
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-01-31  3:00:26
